package com.example.pressync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PressyncApplicationTests {

	@Test
	void contextLoads() {
	}

}
